package com.controlstructure;

public class ForLoopDemo {
	public static void main(String args[]) {

	      for(int x = 10; x < 20; x = x+1) {
	         System.out.print("value of x : " + x );
	         System.out.print("\n");
	      }
	   }
}
