package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class BatchProcessing {
	public static void main(String[] args) {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/emp",
					"root", "root");
			System.out.println("Connected");
			Statement statement = con.createStatement();
			con.setAutoCommit(false);
			String query1 = "insert into products values('101','Laptop',20)";
			String query2 = "insert into products values('105','Mobile',25)";
			String query3 = "update products set qyantity = 30 where product_id = '101'";
			statement.addBatch(query1);
			statement.addBatch(query2);
			statement.addBatch(query3);
			
			int count[] = statement.executeBatch();
			System.out.println(count);
			con.commit();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			if(con != null){
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
