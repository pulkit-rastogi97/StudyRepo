package com.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class TransactionManagement {
	public static void main(String[] args) {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/emp","root", "root");
			System.out.println("Connected");
			con.setAutoCommit(false);
			String query = "insert into products values('101','Laptop',20)";
			Statement statement = con.createStatement();
			int i = statement.executeUpdate(query);
			if(i > 0)
				System.out.println("Record inserted");
			else
				System.out.println("Record not inserted");
			con.commit();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			if(con != null){
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
