package com.psl.movie.service;

import java.util.List;

import com.psl.movie.bean.Movie;

public interface MovieServiceI {
	
	public List<Movie> createMovieList();
	public void sortByLanguage(List<Movie> movieList);
	public void sortByDuration(List<Movie> movieList);
	public void SortByLanguageAndReleaseDate(List<Movie> movieList);

}
