package com.psl.movie.service;

import java.util.List;

import com.psl.movie.bean.Movie;

public class MovieService implements MovieServiceI{

	@Override
	public List<Movie> createMovieList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void sortByLanguage(List<Movie> movieList) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sortByDuration(List<Movie> movieList) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void SortByLanguageAndReleaseDate(List<Movie> movieList) {
		// TODO Auto-generated method stub
		
	}

	

}
