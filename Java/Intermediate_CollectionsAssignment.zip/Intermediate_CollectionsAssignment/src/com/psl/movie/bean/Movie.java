package com.psl.movie.bean;

import java.sql.Time;
import java.util.Date;

public class Movie {

	private String name;
	private Language language;
	private Date releaseDate;
	private Time duration;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Language getLanguage() {
		return language;
	}
	public void setLanguage(Language language) {
		this.language = language;
	}
	public Date getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}
	public Time getDuration() {
		return duration;
	}
	public void setDuration(Time duration) {
		this.duration = duration;
	}
	
	
	public Movie(String name, Language language, Date releaseDate, Time duration) {
		this.name = name;
		this.language = language;
		this.releaseDate = releaseDate;
		this.duration = duration;
	}
	
	@Override
	public String toString() {
		return "Movie [name=" + name + ", language=" + language + ", releaseDate=" + releaseDate + ", duration="
				+ duration + "]";
	}

	
	

	
	
	
}
