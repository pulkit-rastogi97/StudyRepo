package com.psl.movie.bean;

public enum Language {
	
	HINDI,ENGLISH,FRENCH,GERMAN

}
