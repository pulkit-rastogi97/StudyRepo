package com.psl.movie.exception;

public class MovieException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2721640539034757829L;
	String message;
	
	public MovieException(String message)
	{
		super(message);
		this.message=message;
	}
	@Override
	public String toString()
	{
		return this.message;
	}
}
