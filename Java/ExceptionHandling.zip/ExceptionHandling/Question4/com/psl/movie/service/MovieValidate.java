package com.psl.movie.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.EnumSet;

import com.psl.movie.bean.movieLanguage;
import com.psl.movie.exception.MovieException;

public class MovieValidate implements MovieValidateI{
	
	
	EnumSet<movieLanguage> mL = EnumSet.of(movieLanguage.ENGLISH,movieLanguage.HINDI,movieLanguage.FRENCH,movieLanguage.GERMAN,movieLanguage.MALYALI,movieLanguage.MARATHI,movieLanguage.PUNJABI,movieLanguage.SANSKRIT,movieLanguage.SPANISH,movieLanguage.URDU);


	public void readFile() throws MovieException {
		File f = new File("movies.txt");
		try {
			FileReader fr = new FileReader(f);
			BufferedReader bf = new BufferedReader(fr);
			String ch =null;
			while((ch=bf.readLine())!=null)
			{
				String arr[]=ch.split(" ");
				if(!(arr.length==3))
				{
					throw new MovieException("No. of Values are less ");
				}
				else if(Integer.parseInt(arr[arr.length-1])<=-1)
				{
					throw new MovieException("Movie Id is not valid");
				}
				else
				{
				   
				       boolean valid = !mL.contains(movieLanguage.valueOf(arr[arr.length-1]));
				       if(!valid)
				    	   throw new MovieException("Movie Language Not Valid");
				    
				}
					
				
			}
			bf.close();
			
		} catch (IOException | IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	
	
	
}
