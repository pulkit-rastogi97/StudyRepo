package com.psl.movie.service;

import com.psl.movie.exception.MovieException;

public interface MovieValidateI {

	public void readFile() throws MovieException;
}
