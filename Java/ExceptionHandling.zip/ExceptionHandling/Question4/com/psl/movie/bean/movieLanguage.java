package com.psl.movie.bean;

public enum movieLanguage {

	HINDI,ENGLISH,SPANISH,GERMAN,FRENCH,URDU,SANSKRIT,MARATHI,PUNJABI,MALYALI;
}
