package com.psl.question3.service;

import com.psl.question3.exception.ContactException;
import com.psl.question3.bean.Contact;

public interface ContactServiceI {

	public Contact createContact();
	boolean validate(Contact c) throws ContactException;
	
}
