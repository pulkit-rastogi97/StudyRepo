package com.psl.question3.pl;

import java.util.Scanner;

import com.psl.question3.bean.Contact;
import com.psl.question3.bean.ContactStack;
import com.psl.question3.exception.ContactException;
import com.psl.question3.service.ContactService;
import com.psl.question3.service.ContactServiceI;

public class ContactMain {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int ch =0;
		Contact user = new Contact();
		ContactStack<Contact> stack = new ContactStack<>();
		ContactServiceI csi = new ContactService();
		do {
		System.out.println("What would you like to do ? ");
		System.out.println("1. Create a stack ");
		System.out.println("2. Push into the stack ");
		System.out.println("3. Pop from stack ");
		System.out.println("4. Exit ");
		ch=sc.nextInt();
		switch(ch)
		{
		case 1: System.out.println("Enter the size of the stack :: ");
				int size = sc.nextInt();
				stack = new ContactStack<Contact>(size);
				break;
		case 2: System.out.println("Kindly fill the form for the element :: ");
				user = csi.createContact();
				try{
					if(csi.validate(user)) {
						stack.push(user);
						System.out.println("Successfully pushed");
					}
				}catch(ContactException e)
				{
					System.out.println(e.getMessage());
				}
				break;
		case 3: try {
				stack.pop();
			} catch (ContactException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
				break;
		case 4: ch = 5;
				break;
		default:System.out.println("Invalid choice");		
		}		
		}while(ch>0 && ch<=4);
		sc.close();
		}
	}

