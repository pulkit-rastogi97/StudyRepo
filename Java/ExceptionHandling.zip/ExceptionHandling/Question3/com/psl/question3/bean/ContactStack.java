package com.psl.question3.bean;

import com.psl.question3.exception.ContactException;

@SuppressWarnings("hiding")
public class ContactStack <Contact>{
	
	private Contact[] stack;
	private int top,stackSize;
	
	public ContactStack()
	{
		this.top=-1;
	}
	@SuppressWarnings("unchecked")
	public ContactStack(int size)
	{
		this.stackSize=size;
		stack = (Contact[]) new Object[size];
		this.top=-1;		
	}
	
	public void push(Contact c) throws ContactException
	{
		if(this.top==-1)
		{
			throw new ContactException("Stack is unintialized. Can't push element ");
		}
		else if(this.isFull())			
		{
			throw new ContactException(" Stack is Full. Can't push element ");	
		}
		this.stack[++top]=c;		
	}
	
	public void pop() throws ContactException
	{
		if(this.isEmpty())
			throw new ContactException("Stack is Empty. Can't delete elements ");
		
		Contact c = this.stack[top--];
		this.stack[top--]=null;
		System.out.println("Removed element :: "+c);	
	}

	public boolean isFull() {
		
		return (top==stackSize-1);
	}
	
	public boolean isEmpty()
	{
		return (top==-1);
	}
	
	

}
