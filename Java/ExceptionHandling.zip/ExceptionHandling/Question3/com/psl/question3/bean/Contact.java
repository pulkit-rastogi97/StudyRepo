package com.psl.question3.bean;

import java.time.LocalDate;
import java.util.regex.Pattern;

import com.psl.question3.exception.ContactException;


public class Contact {

	private String firstName, lastName, middleName, gender, address, area, city, state, country, telephoneNumber, mobileNumber, email, website, pincode;
	LocalDate dateOfBirth, anniversary;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getTelephoneNumber() {
		return telephoneNumber;
	}
	public void setTelephoneNumber(String telephoneNumber) {
		this.telephoneNumber = telephoneNumber;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public LocalDate getAnniversary() {
		return anniversary;
	}
	public void setAnniversary(LocalDate anniversary) {
		this.anniversary = anniversary;
	}
	public Contact(String firstName, String lastName, String middleName, String gender, String address, String area,
			String city, String state, String country, String telephoneNumber, String mobileNumber, String email,
			String website, String pincode, LocalDate dateOfBirth, LocalDate anniversary) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.middleName = middleName;
		this.gender = gender;
		this.address = address;
		this.area = area;
		this.city = city;
		this.state = state;
		this.country = country;
		this.telephoneNumber = telephoneNumber;
		this.mobileNumber = mobileNumber;
		this.email = email;
		this.website = website;
		this.pincode = pincode;
		this.dateOfBirth = dateOfBirth;
		this.anniversary = anniversary;
	}
	
	public Contact() {
		// TODO Auto-generated constructor stub
	}
	public boolean validate() throws ContactException
	{
		String regex = "^[a-zA-Z0-9_+&*-]+(?:\\\\.\"+ \r\n" + 
				"                            \"[a-zA-Z0-9_+&*-]+)*@\" + \r\n" + 
				"                            \"(?:[a-zA-Z0-9-]+\\\\.)+[a-z\" + \r\n" + 
				"                            \"A-Z]{2,7}$";
		
		Pattern pat = Pattern.compile(regex);
		
	
		if(this.firstName==null || this.lastName==null || this.firstName.isBlank() || this.lastName.isBlank())
			throw new ContactException("First Name and Last Name is mandatory");
		else if(this.dateOfBirth==null)
			throw new ContactException("Date Of Birth is a mandatory field");
		else if(this.email==null)
			throw new ContactException("Email address is a mandatory field ");
		else if(this.telephoneNumber==null && this.mobileNumber == null)
			throw new ContactException("Either of two Telephone or Mobile number should be entered");
		else if(!pat.matcher(email).matches())
			throw new ContactException("Email address must be of the format :: \"user_name@domain.com\" ");
			
		return true;
		
	}
}
