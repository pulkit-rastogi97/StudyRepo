package com.psl.question1.pl;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

import com.psl.question1.bean.Contact;
import com.psl.question1.exception.ContactException;

public class ContactMain {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int ch =0;
		Contact user = new Contact();
		do {
		System.out.println("What would you like to do ? ");
		System.out.println("1. Fill the form ");
		System.out.println("2. Exit ");
		ch = sc.nextInt();
		sc.nextLine();
		switch(ch)
		{
		case 1: System.out.println("Enter the information :: ");
				System.out.println("First Name ::  ");
				user.setFirstName(sc.nextLine());
				System.out.println("Middle Name :: ");
				user.setMiddleName(sc.nextLine());
				System.out.println("Last Name :: ");
				user.setLastName(sc.nextLine());
				System.out.println("Date Of Birth (dd/MM/yyyy) :: ");
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
				try {
			LocalDate date = LocalDate.parse(sc.nextLine(),formatter);
			user.setDateOfBirth(date);}catch(DateTimeParseException e)
				{
					try {
						throw new ContactException(e.getMessage());
					}catch(ContactException es){
						System.out.println(es.getMessage());
					}
				}
						
				System.out.println("Gender :: ");
				user.setGender(sc.nextLine());
				
				System.out.println("Anniversary (dd/MM/yyyy):: ");
				try {
			LocalDate date1 = LocalDate.parse(sc.nextLine(),formatter);
			user.setAnniversary(date1);}catch(DateTimeParseException e)
				{
					try {
						throw new ContactException(e.getMessage());
					}catch(ContactException es)
					{
						System.out.println(e.getMessage());
					}
				}
				
				System.out.println("Address :: ");
				user.setAddress(sc.nextLine());
				
				System.out.println("Area :: ");
				user.setArea(sc.nextLine());
				
				System.out.println("City :: ");
				user.setCity(sc.nextLine());
				
				System.out.println("Pincode :: ");
				user.setPincode(sc.nextLine());
				
				System.out.println("State :: ");
				user.setState(sc.nextLine());
				
				System.out.println("Country :: ");
				user.setCountry(sc.nextLine());
				
				System.out.println("Telephone Number ::");
				user.setTelephoneNumber(sc.nextLine());
				
				System.out.println("Mobile Number :: ");
				user.setMobileNumber(sc.nextLine());
				
				System.out.println("Email :: ");
				user.setEmail(sc.nextLine());
				
				System.out.println("Website :: ");
				user.setWebsite(sc.nextLine());
				
				try {
				if(user.validate())
					System.out.println("Sucessfully Submitted the information ");
				}catch(ContactException e ) {
				System.out.println(e.getMessage());
				}
				break;
		case 2: ch = 6;
				break;
		default: System.out.println("Inavlid choice");}
		}while(ch>0 && ch<=2);
		
		
		
	
		sc.close();
		}
	}

