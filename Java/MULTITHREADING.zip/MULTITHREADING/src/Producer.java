import java.util.Random;


public class Producer implements Runnable{
	Fruits fr;
	public Producer(Fruits fr){
		this.fr=fr;
		new Thread(this).start();
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		Random r = new Random();
		for(int i =0;i<3;i++){
		synchronized(fr){
			fr.setApple(r.nextInt(10));
			fr.setGrape(r.nextInt(10));
			fr.setOrange(r.nextInt(10));
			fr.setWatermelon(r.nextInt(10));
			
			fr.notify();
			try {
				fr.wait(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}
	}
	

}
