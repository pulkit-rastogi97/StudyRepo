import java.util.Random;


public class RandomNumbers implements Runnable {
	
	Storage st;
	public RandomNumbers(Storage st){
		this.st = st;
		new Thread(this).start();
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		Random r = new Random();
		for(int i =0 ;i<3;i++){
		synchronized(st){
			int rand = r.nextInt(100)-50;
			st.setI(rand);
			st.notify();
			try {
				st.wait(10);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}
		
	}
	

}
