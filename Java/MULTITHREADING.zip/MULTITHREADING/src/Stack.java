import java.util.*;
public class Stack<T> {
	
	ArrayList<T>list=new ArrayList<T>(10);
	
	
}
