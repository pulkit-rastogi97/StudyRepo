
public class Question2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Storage s = new Storage();
		RandomNumbers r = new RandomNumbers(s);
		Determine d = new Determine(s);
	}

}
