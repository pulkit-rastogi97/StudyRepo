
class Question3 {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Fruits market = new Fruits();
		Producer producer = new Producer(market);
		Consumer consumer = new Consumer(market,1,2,3,4);
		
	}

}
