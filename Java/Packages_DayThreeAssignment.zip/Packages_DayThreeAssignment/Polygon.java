package esg.itp.shape;

public interface Polygon {

	void calArea();
	void calPeri();
	void display();
	
	
}
