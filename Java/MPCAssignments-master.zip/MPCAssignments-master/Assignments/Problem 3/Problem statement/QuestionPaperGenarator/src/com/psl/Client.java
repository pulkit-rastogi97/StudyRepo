package com.psl;

import java.util.*;

import com.bean.Category;
import com.bean.Complexity;
import com.bean.Criteria;
import com.bean.Question;
import com.util.DataManagerImpl;

public class Client {
	public static void main(String[] args) {
		// Call your functionalities from here to test your code.
	}
}
