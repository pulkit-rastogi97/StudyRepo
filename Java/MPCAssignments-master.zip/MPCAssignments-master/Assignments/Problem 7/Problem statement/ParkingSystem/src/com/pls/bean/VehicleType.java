package com.pls.bean;

public enum VehicleType 
{
Car,Bus,Bike,Truck

}
