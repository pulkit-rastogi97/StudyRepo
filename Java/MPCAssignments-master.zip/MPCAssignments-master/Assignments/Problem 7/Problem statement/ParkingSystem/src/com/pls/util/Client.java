package com.pls.util;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.pls.bean.ParkingSlot;
import com.pls.bean.Vehicle;
import com.pls.exception.ParkingFullException;
import com.pls.impl.ParkingSystemImpl;


public class Client {

	public static void main(String[] args) {

		
		
	}

}