package com.psl.main;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.psl.bean.Sector;
import com.psl.bean.Stock;
import com.psl.util.StockMarketSystemImpl;


public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		
	}

}
