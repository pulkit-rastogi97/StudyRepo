package com.psl.bean;

public enum Sector {
Pharma,Infotech,Power,PSU
}
