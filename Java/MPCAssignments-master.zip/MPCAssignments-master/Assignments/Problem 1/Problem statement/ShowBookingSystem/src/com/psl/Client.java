package com.psl;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.bean.Show;
import com.exception.InvalidSeatNumberException;
import com.exception.SeatsNotAvailableException;
import com.exception.UnknownShowException;
import com.util.DataManagerImpl;
//import com.bean.Show;

public class Client {
	
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
	}
}