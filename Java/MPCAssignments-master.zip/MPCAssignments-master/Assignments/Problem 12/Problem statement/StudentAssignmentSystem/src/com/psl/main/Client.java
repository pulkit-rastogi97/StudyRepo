package com.psl.main;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.psl.bean.Student;
import com.psl.bean.Subject;
import com.psl.util.StudentAssignmentImpl;


public class Client {

	public static void main(String[] args) {
	
		
	}
}