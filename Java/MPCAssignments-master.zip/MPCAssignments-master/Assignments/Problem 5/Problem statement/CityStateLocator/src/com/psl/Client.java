package com.psl;

import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.exception.CityNotFoundException;
import com.exception.InvalidStateException;
import com.util.DataManagerImpl;


public class Client {
	
	public static void main(String[] args) throws InvalidStateException {
		//Call your methods from here  to test the code implemented
		
	}
}