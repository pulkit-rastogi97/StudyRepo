package com.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

import com.exception.CityNotFoundException;
import com.exception.InvalidStateException;


// Override and implement the methods of Interface DataManager here 
public class DataManagerImpl implements DataManager {
}
