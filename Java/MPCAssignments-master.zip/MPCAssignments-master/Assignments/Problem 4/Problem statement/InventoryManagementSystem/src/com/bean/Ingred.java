package com.bean;

public enum Ingred {
	protein,vitamin,fat
}

