package com.psl;

import java.util.ArrayList;
import java.util.List;

import com.bean.Item;
import com.exception.NoDataFoundException;
import com.util.InventoryServiceImpl;

public class Client {

	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		
	}
		
}
