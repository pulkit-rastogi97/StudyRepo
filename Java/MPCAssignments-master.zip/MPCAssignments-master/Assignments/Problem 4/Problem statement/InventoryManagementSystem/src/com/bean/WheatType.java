package com.bean;

public enum WheatType {
	Punjab1002,NI2002,Khapali,Locwan33
}
