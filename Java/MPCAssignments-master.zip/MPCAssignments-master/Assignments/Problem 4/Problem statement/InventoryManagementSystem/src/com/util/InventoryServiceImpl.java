package com.util;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.*;

import com.bean.Cheese;
import com.bean.CheeseType;
import com.bean.Item;
import com.bean.Milk;
import com.bean.MilkType;
import com.bean.Wheat;
import com.bean.WheatType;
import com.exception.NoDataFoundException;

// Override and implement all the methods of DBConnectionUtil Interface in this class
public class InventoryServiceImpl implements InventoryService {

		
}
