package com.bean;

public enum MilkType {
	CowMilk,BuffaloMilk
}
