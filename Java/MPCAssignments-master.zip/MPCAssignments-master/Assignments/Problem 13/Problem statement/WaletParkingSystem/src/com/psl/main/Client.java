package com.psl.main;

import java.util.Set;

import com.psl.bean.ParkingBlock;
import com.psl.exception.ParkingFullException;
import com.psl.util.ParkingSystemImpl;


public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
	}
}
