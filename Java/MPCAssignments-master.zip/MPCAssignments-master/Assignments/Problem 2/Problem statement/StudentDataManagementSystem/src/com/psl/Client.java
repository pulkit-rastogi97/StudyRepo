package com.psl;

import java.util.ArrayList;
import java.util.List;

import com.psl.beans.Student;
import com.psl.exceptions.InsufficientDataException;
import com.psl.util.StudentDataManager;

public class Client {
	
	public static void main(String[] args) {
		
		
	}
}
