package com.psl.main;

import java.text.SimpleDateFormat;
import java.util.List;

import com.psl.bean.Ship;
import com.psl.util.ShipyardSystemImpl;

public class Client {

	public static void main(String[] args) {
		
		
	}

}
