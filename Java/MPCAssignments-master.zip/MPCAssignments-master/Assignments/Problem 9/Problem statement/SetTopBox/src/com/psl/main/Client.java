package com.psl.main;

import java.util.List;

import com.psl.bean.Channel;
import com.psl.util.SetTopBoxManagementSystemImpl;



public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
	}

}
