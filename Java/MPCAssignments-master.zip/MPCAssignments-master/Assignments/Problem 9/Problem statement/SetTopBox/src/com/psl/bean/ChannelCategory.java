package com.psl.bean;

public enum ChannelCategory {
News,Movie,Cartoon,Sports
}
