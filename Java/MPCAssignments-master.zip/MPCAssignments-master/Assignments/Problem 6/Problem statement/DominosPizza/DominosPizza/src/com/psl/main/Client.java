package com.psl.main;

import java.util.ArrayList;
import java.util.List;

import com.psl.bean.Dish;
import com.psl.bean.Location;
import com.psl.bean.Order;
import com.psl.util.DominozPizzaDeliveryImpl;

/*
 * @Author: Gandhali Inamdar
 */
public class Client {

	public static void main(String[] args) 
	{
		
	}

}
