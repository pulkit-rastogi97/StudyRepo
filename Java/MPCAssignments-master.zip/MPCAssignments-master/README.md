# MPCAssignments
Sample Persistent Systems Limited (PSL) MPC Assignments for freshers

Every fresher recruited by Persistent Systems needs to give MPC test. I also gave that test in Java domain. I was lucky to get some practice assignments from my seniors.
It was really helpful. I thought to keep it on Git for other students as well.

You might find some assignments repeated, please bare with that.
Folder [Assignments](https://github.com/MRohit/MPCAssignments/tree/master/Assignments) contains the format in which you will asked to code the solution.
Folder [Java Theory](https://github.com/MRohit/MPCAssignments/tree/master/Java%20Theory) contains MCQ material and
folder [training](https://github.com/MRohit/MPCAssignments/tree/master/training) contains sample MPC questions for practice.

Good luck
