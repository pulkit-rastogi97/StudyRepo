package com.psl.beans;

/**
 * 
 * @author YOGESH SHINDE
 * @since October 2014
 *
 */

public enum Units 
{
	kg, gallon, grams, nos;
}