package com.psl.exceptions;

/**
 * 
 * @author YOGESH SHINDE
 * @since October 2014
 *
 */

public class InsufficientDataException extends Exception
{
	private static final long serialVersionUID = 1L;

	public InsufficientDataException()
	{
		super("Insufficent Data Exception..!!!");
	}
}
