package QuestionOne;

public enum Vehicle_Type {
	TWO_WHEELER,FOUR_WHEELER;

}
