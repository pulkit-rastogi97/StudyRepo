import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;


public class SerializeWageEmp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File file = new File("serl2.txt");
		try
		{
			FileOutputStream fout = 
					new FileOutputStream(file);
			ObjectOutputStream bout = 
					new ObjectOutputStream(fout);
			Address address = new Address("411043","Pune");
			WageEmp emp = new WageEmp(122,"Priya",30000,address,30,300);
			bout.writeObject(emp);
			bout.flush();
			bout.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
