import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;


public class SerializeEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File file = new File("serl3.txt");
		try
		{
			FileOutputStream fout = 
					new FileOutputStream(file);
			ObjectOutputStream bout = 
					new ObjectOutputStream(fout);
			Address address = new Address("411044","Pune");
			Employee emp = new Employee(110,"Nisha",50000,address);
			bout.writeObject(emp);//serialize object
			bout.flush();
			bout.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
