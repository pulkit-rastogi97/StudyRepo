import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;


public class DeserializeEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee emp = null;
		
		File file = new File("serl3.txt");
		
		try
		{
			FileInputStream fin = new FileInputStream(file);
			ObjectInputStream bin = new ObjectInputStream(fin);
			emp = (Employee)bin.readObject();
			System.out.println(emp);
			bin.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
