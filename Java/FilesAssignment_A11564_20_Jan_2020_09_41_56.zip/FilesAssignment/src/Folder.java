import java.io.*;
import java.util.*;

public class Folder {

	static Map<Integer, String> map;
	
	 static void RecursivePrint(File[] arr,int index,int level)  
     { 
					map=new HashMap<Integer,String>();
         if(index == arr.length) 
             return; 
           
         for (int i = 0; i < level; i++) 
             System.out.print("\t"); 
           
         if(arr[index].isFile()) 
             {
        	 System.out.println(arr[index].getName());
        	 map.put(index, arr[index].getName());
             
             }
           
         else if(arr[index].isDirectory()) 
         { 
             System.out.println("[" + arr[index].getName() + "]"); 
             RecursivePrint(arr[index].listFiles(), 0, level + 1); 
        	 map.put(index, arr[index].getName());
         } 
            
         RecursivePrint(arr,++index, level);  
    } 
      
	 static void search(File[] arr,int index,int level, String fName)  
     { 
					
         if(index == arr.length) 
             return; 
             
         if(arr[index].isFile()) 
             {
        	 if(arr[index].getName().equals(fName))
        		 System.out.println("Found");
             
             }
           
         else if(arr[index].isDirectory()) 
         { 
        	 if(arr[index].getName().equals(fName))
        		 System.out.println("Found");
         } 
            
         RecursivePrint(arr,++index, level);  
    } 
	 
	 static public void count() throws IOException
	 {
		 File f1=new File("H:\\personality\\Example.txt"); 
	      String[] words=null;   
	      int wc=0;     
	      FileReader fr = new FileReader(f1);   
	      BufferedReader br = new BufferedReader(fr);    
	      String s;
	      while((s=br.readLine())!=null)    
	      {
	         words=s.split(" ");   
	         wc=wc+words.length;  
	      }
	      fr.close();
	      System.out.println("Number of words in the file:" +wc);  
	 }
	 
    public static void main(String[] args)
    {
    { 
    	try{
        String maindirpath = "H:\\personality"; 
        File maindir = new File(maindirpath); 
           
        if(maindir.exists() && maindir.isDirectory()) 
        {  
            File arr[] = maindir.listFiles(); 
              
            System.out.println("Files from main directory : " + maindir);               
            RecursivePrint(arr,0,0);  
            System.out.println("1. Map 2.Search 3.CountWords");
            Scanner sc= new Scanner(System.in);
            int ch = sc.nextInt();
            
            switch(ch)
            {
            case 1: System.out.println(map);
            		break;
            case 2:
            		search(arr,0,0,"Example.txt");
            		break;
            case 3:
            		count();
            		break;
            }
       }  
    }catch(Exception e)
    	{
    	System.out.println(e.getMessage());
    	}
}
}}