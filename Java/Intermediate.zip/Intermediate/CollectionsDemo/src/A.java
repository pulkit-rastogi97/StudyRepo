
public class A {
int a;
}
class B extends A
{
int b;	
}
class C extends B
{
	int c;
}
