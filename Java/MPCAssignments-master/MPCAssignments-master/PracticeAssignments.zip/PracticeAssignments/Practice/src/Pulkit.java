
public class Pulkit 
{
	public static void main(String[] args) 
	{
	}
}
