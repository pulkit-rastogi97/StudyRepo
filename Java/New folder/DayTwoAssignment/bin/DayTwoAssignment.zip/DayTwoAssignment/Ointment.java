
public class Ointment extends Medicine{

	@Override
	public void displayLabel()
	{
		super.displayLabel();
		System.out.println("for external use only");
	}
}
