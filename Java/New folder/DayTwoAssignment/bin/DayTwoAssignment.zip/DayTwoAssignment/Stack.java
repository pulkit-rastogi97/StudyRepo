
public interface Stack {
	void push(int i);
	int pop();
	

}
