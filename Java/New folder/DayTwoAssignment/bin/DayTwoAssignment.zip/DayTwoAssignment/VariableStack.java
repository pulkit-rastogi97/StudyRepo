
public class VariableStack implements Stack{
	private int size;
	
	public VariableStack(int size)
	{
		this.size=size;
	}

	@Override
	public void push(int i) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int pop() {
		// TODO Auto-generated method stub
		return 0;
	}

}
