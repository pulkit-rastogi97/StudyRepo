
public class Syrup extends Medicine{

	@Override
	public void displayLabel()
	{
		super.displayLabel();
		System.out.println("Should be consumed within 1 month after opening");
	}
}
