package Question7;

public class DisplayFactorial {

	
}
