package Question3;

public class Counter implements Runnable{
	
	Storage s;
	public Counter(Storage s)
	{
		this.s=s;
	}
	@Override
	public void run()
	{
		for(int i = 0; i< 100; i++)
		{
		  s.arr[i]=i;
		  //System.out.println("count = "+s.arr[i]);
		}
		
	}

}
