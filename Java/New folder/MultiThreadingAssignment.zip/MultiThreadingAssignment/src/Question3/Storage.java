package Question3;

import java.util.Arrays;

public class Storage {

	int arr[]=new int[100];
	public Storage()
	{
		arr=new int[100];
	}
	public int[] getArr() {
		return arr;
	}
	public void setArr(int[] arr) {
		this.arr = arr;
	}
	@Override
	public String toString() {
		return "Storage [arr=" + Arrays.toString(arr) + "]";
	}
	
	
	
}
