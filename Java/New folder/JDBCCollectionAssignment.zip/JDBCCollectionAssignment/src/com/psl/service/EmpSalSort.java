package com.psl.service;

import java.util.Comparator;

import com.psl.bean.Employee;

public class EmpSalSort implements Comparator<Employee> {

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		return (int)(o1.getSalary()-o2.getSalary());
	}

}
