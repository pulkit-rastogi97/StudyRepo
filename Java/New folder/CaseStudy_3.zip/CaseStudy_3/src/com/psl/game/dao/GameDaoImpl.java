package com.psl.game.dao;

public class GameDaoImpl {

}
