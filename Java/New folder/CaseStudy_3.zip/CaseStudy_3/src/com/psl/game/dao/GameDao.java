package com.psl.game.dao;

public class GameDao {

	public validateUserId()
}
