
public class QuesOne {

}
