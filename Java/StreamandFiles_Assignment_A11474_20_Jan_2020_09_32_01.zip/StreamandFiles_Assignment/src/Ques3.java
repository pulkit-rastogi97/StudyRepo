import java.io.File;


public class Ques3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1 = "H:/Users/ambuj_suri/Desktop/Java/Day1/src";
		Ques3 obj = new Ques3();
		Boolean val = obj.searchFile(str1,"Ques5.java");
		if(val == true)
		System.out.println("Found");
		else
			System.out.println("Not Found");	
				
		
	}
	public Boolean searchFile(String path, String filename)
	{
		File f = new File(path); // current directory
		Boolean value=false;
		File[] files = f.listFiles();
		for (File file : files) {
			if (file.getName().equals(filename)) 
			{
				
				value = true;
				break;
			} 
			else 
			{
				
				value = false;
			}
	}
			
		return value;
	}
		
	}

