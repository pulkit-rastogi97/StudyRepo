import java.io.File;


public class Ques1 {
	public static void main(String[]args)
	{
		String str1 = "H:/Users/ambuj_suri/Desktop/Java/Day1/src";
	
		File f = new File(str1); // current directory

		File[] files = f.listFiles();
		for (File file : files) {
			if (file.isDirectory()) {
				System.out.println("directory:");
			} else {
				System.out.println("file:");
			}
	}
}
}
