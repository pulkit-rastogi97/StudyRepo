document.getElementById("checkoutdiv").style.display = "none";
document.getElementById("products").onmouseover = function(event){		
	// Your code here
};
document.getElementById("checkout").onclick =function(){
	document.getElementById("checkoutdiv").style.display = "";
};
document.getElementById("products").onclick = function(event){
	// Your code here
};
document.getElementById("cart-content").onclick = function(event){	
	// Your code here	
};
document.getElementById("remove").onclick = function(){	
	// Your code here
};
document.getElementById("submit").onclick = function(){
	// Here is AJAX implementation to send data to the server in .jsp file.
};
function changePic(name,elemImg){	
}